<?php
/*
	* @package Latest Posts-Kunena  Plugin for J!MailALerts Component  
	* @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
	* @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
	* @link     http://www.techjoomla.com
*/
defined('_JEXEC') or die('Restricted access');
	?>
	<h2 class="subTitle"><?php echo $plugin_params->get('plugintitle'); 
	<table class= "jma_postku product-table">
		<tr>
			<th class = "jma_postku_th"><?php echo JText::_("POST_SUBJECT_KU"); ?></th>
			<th class = "jma_postku_th"><?php echo JText::_("DATE_CREATED_KU"); ?></th>
		</tr>
		<?php
		$cat_array=array();
		foreach ($vars as $row)
		{
			if (in_array($row->catid, $cat_array))
			{
		?>	
				<tr>
					<td><a href="<?php echo $row->link;?>"><?php echo $row->subject; ?></a></td>				
					<td><?php echo date("Y-m-d",$row->time); ?> </td>					
			   </tr>
			<?php
			}
			else
			{
				array_push($cat_array, $row->catid);
			?>
				<tr>
					<td class="jma_postku_td"><?php echo JText::_("CATEGORY_KU");?>: <?php echo $row->catname; ?></td>
				</tr>
				<tr>
					<td class="jma_postku_td_subject"><a href="<?php echo $row->link;?>"><?php echo $row->subject; ?></a></td>				
					<td class="jma_postku_td_date"><?php echo date("Y-m-d",$row->time); ?> </td>					
			   </tr>
			<?php
			}	
			?>				    
		<?php
		}
		?>
	</table>
