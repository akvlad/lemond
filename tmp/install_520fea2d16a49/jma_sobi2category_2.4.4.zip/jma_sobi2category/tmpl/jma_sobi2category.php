<?php
/*
 * @package J!MailAlerts Plugin for SOBI2 Latest Item Additions In A Category
 * @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
 * @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
 * @link     http://www.techjoomla.com
 */
defined('_JEXEC') or die('Restricted access');
$params =& $this->params;
?>
<h2 class="subTitle">
<?php

echo $plugin_params->get("plugintitle");

$show_image=$plugin_params->get("show_image");
?>
</h2>
<table class="jma_sobi2category_table product-table">
	<?php
	if($show_image)
	{
	    echo "<tr>";
	    $i=1;
	    foreach($vars as $row)
	    {
	        if($i%4==0)
	        {
	            ?>
				</tr>
				<tr>
				<td class="jma_sobi2_category_td"><br /> 
					<a	href="<?php  echo $row->link;?>"> <?php  echo $row->title;?> </a> 
					<br />
    					<?php 
    					if($row->image_url=='')
    					{
    					    ?>
    					    <a href="<?php  echo $row->link;?>"> </a>
    					    <img src="<?php echo $row->image_url;?>"  alt="<?php echo JText::_('NO_IMAGE_SOBI2');?>" /> 
    					    <?php 
    					}
    					else
    					{
    					    ?> 
    					    <a href="<?php  echo $row->link;?>"> 
    					    <img class="jma_sobi2_category_img" src="<?php echo $row->image_url;?>"	alt="<?php echo JText::_('NO_IMAGE_SOBI2'); ?>" />
    					    </a> 
    					    <?php
    					}
    					    ?>
				</td>
    		    <?php
	        }
	        else
	        {
	            ?>
				<td class="jma_sobi2_category_td">
					<a href="<?php  echo $row->link;?>">
	                    <?php  echo $row->title;?>
	                </a>
	                <br /> 
    					<?php 
    					if($row->image_url=='')
    					{
    					    ?>
    					    <a href="<?php  echo $row->link;?>"> </a>
    					    <img src="<?php echo $row->image_url;?>" alt="<?php echo JText::_('NO_IMAGE_SOBI2');?>" /> 
    					    <?php 
    					}
    					else
    					{
    					    ?> 
    					    <a href="<?php  echo $row->link;?>"> 
    					    <img class="jma_sobi2_category_img" src="<?php echo $row->image_url;?>"	alt="<?php echo JText::_('NO_IMAGE_SOBI2'); ?>" />
    					    </a> 
    					    <?php
    					}
    					    ?> 
				</td>
	           <?php
	        }
	        $i++;
	    }
	    ?>
	    </tr>
	<?php
	}
	else//if not showing image
	{
	    foreach($vars as $row)
	    {
	        ?>
			<tr>
				<td>
					<li>
						<a href="<?php echo $row->link;?>"><?php echo $row->title;?></a>
					</li>
				</td>
			</tr>
	        <?php
	    }
	}
	        ?>
	</table>
