<?php
/*
 * @package J!MailAlerts Plugin for SOBI2 Latest Item Additions In A Category
 * @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
 * @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
 * @link     http://www.techjoomla.com
 */

// Do not allow direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.plugin.plugin' );
//include plugin helper file
$jma_helper=JPATH_SITE.DS.'components'.DS.'com_jmailalerts'.DS.'helpers'.DS.'plugins.php';
if(JFile::exists($jma_helper)){
	include_once($jma_helper);
}
else//this is needed when JMA integration plugin is used on sites where JMA is not installed
{
	if(JVERSION>'1.6.0'){
		$jma_integration_helper=JPATH_SITE.DS.'plugins'.DS.'system'.DS.'plg_sys_jma_integration'.DS.'plg_sys_jma_integration'.DS.'plugins.php';
	}else{
		$jma_integration_helper=JPATH_SITE.DS.'plugins'.DS.'system'.DS.'plg_sys_jma_integration'.DS.'plugins.php';
	}
	if(JFile::exists($jma_integration_helper)){
		include_once($jma_integration_helper);
	}
}

/*load language file for plugin frontend*/
$lang = & JFactory::getLanguage();
$lang->load('plg_emailalerts_jma_sobi2category', JPATH_ADMINISTRATOR);
//class plgEmailalertsjma_sobi2category extends JPlugin
class plgEmailalertsjma_sobi2category extends JPlugin
{
    function plgEmailalertsSobi2category(& $subject, $config)
    {
        parent::__construct($subject, $config);
        if($this->params===false) {//unknown
            $jPlugin =& JPluginHelper::getPlugin('emailalerts','jma_sobi2category');
            $this->params = new JParameter( $jPlugin->params);
        }
    }

    function onEmail_jma_sobi2category($id, $date, $userparam, $fetch_only_latest)
    {
        require_once(JPATH_ADMINISTRATOR . DS .'components'. DS .'com_jmailalerts'. DS .'plugins'. DS .'emailalerts'. DS .'helper.php');
        require_once (JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');
		
		$areturn	=  array();
        if(!$id)
		{
        	$areturn[0] =$this->_name;
		    $areturn[1]	= '';
            $areturn[2]	= '';
            return $areturn;
        }                   
        //Requiured Declarations
        $params = $this->params;
                
        $list = $this->getList($userparam,$fetch_only_latest,$date);

        $areturn	=  array();
        $areturn[0]	= $this->_name;
        if(empty($list))
        {
            $areturn[1]='';
            $areturn[2]='';
        }
        else
        {
            //get all plugin parameters in the variable, this will be passed to plugin helper function
	        $plugin_params=&$this->params;
            //create object for helper class
	        $helper = new pluginHelper();    
            //call helper function to get plugin layout
            $ht = $helper->getLayout($this->_name, $list,$plugin_params);
            
            $areturn[1]	= $ht;
            //call helper function to get plugin CSS layout path
            $cssfile= $helper->getCSSLayoutPath($this->_name,$plugin_params);
            
            $cssdata=JFile::read($cssfile);
            $areturn[2] = $cssdata;
        }
        return $areturn;
    }//onEmail_jma_sobi2category() ends

    
    function getList(&$userparam, &$fetch_only_latest,$last_date)
    {
        $mainframe = JFactory::getApplication();
        $db			=& JFactory::getDBO();
        $user		=& JFactory::getUser();
        
        //get user preferences for this plugin parameters(shown in frontend) 
        $count		= (int) $userparam['count'];
        $catid		= trim( $userparam['category'] );
        $show_image		= $userparam['show_image'];
        $integrate_gallery	= $userparam['integrate_gallery'];
            
        $params = $this->params;
        $replace = JURI::root();
        $nullDate	= $db->getNullDate();
        $date =& JFactory::getDate();
        $now = $date->toMySQL();

        if(!$catid)
        return false;

        $query = 'SELECT i.title,i.itemid,i.icon,i.image,c.name '.
				 ' FROM #__sobi2_item AS i'.
				 ' LEFT JOIN #__sobi2_cat_items_relations cir ON cir.itemid=i.itemid'.
				 ' LEFT JOIN #__sobi2_categories c ON c.catid=cir.catid'.
				 ' WHERE c.catid IN ('.$catid.')'.
        		 ' AND i.published = 1';
        $where=	 ' AND (i.publish_up='.$db->Quote($nullDate).' OR i.publish_up <= '.$db->Quote($now).' )'.
                 ' AND (i.publish_down = '.$db->Quote($nullDate).' OR i.publish_down >= '.$db->Quote($now).' )'; 
         
        //get only fresh content 
        if($fetch_only_latest)
        {
            $query .=" AND i.publish_up >=";
            $query .=$db->Quote($last_date);
        }

        $query.=$where;
        $query .=" ORDER BY i.publish_up DESC";

        $db->setQuery($query, 0, $count);
        $rows = $db->loadObjectList();

        $lists= array();
        if($rows)
        {
            $i=0;
            $items= array();
            if($mainframe->isAdmin())
            {
                foreach($rows as $row)
                {
                    if(!in_array($row->itemid, $items))//to avoid duplicate entris of items assigned to more than 1 categories
                    {
                        array_push($items, $row->itemid);
                        $lists[$i]->category_name = $rows[0]->name;
                        $lists[$i]->title=$row->title;
                        $lists[$i]->link=JRoute::_($replace."index.php?option=com_sobi2&sobi2Task=sobi2Details&sobi2Id=".$row->itemid);
                        $lists[$i]->link=str_replace("&", "&amp;",$lists[$i]->link);

                        $url='';
                        if($show_image)
                        {
                            if($row->icon){//If icon is present
                                $url=$replace."images/com_sobi2/clients/".$row->icon;
                            }
                            elseif($row->image){//if logo is present
                                $url = $replace ."images/com_sobi2/clients/".$row->image;
                            }

                            if($integrate_gallery)//if gallery plgin is used
                            {
                                $query = "SELECT * FROM `#__sobi2_plugin_gallery` WHERE itemid=".$row->itemid." LIMIT 1";
                                $db->setQuery( $query );
                                $image=$db->loadObject();
                                $img='';
                                if($image)
                                {
                                    $thumbSrc = "{$image->itemid}/{$image->thumb}";
                                    $url=$replace ."/images/com_sobi2/gallery/".$thumbSrc;
                                }
                            }
                        }
                        $lists[$i]->image_url = htmlspecialchars($url);
                        $i++;
                    }
                }
            }
            else
            {
                foreach($rows as $row)
                {
                    if(!in_array($row->itemid, $items))//to avoid duplicate entris of items assigned to more than 1 categories
                    {
                        array_push($items, $row->itemid);
                        $lists[$i]->category_name = $rows[0]->name;
                        $lists[$i]->title=$row->title;
                       
                        $lists[$i]->link=JURI::root().substr(JRoute::_('index.php?option=com_sobi2&sobi2Task=sobi2Details&sobi2Id='.$row->itemid),strlen(JURI::base(true))+1);

                        $url='';
                        if($show_image)
                        {
                            if($row->icon){//If icon is present
                                $url=$replace."images/com_sobi2/clients/".$row->icon;
                            }
                            elseif($row->image){//if logo is present
                                $url = $replace ."images/com_sobi2/clients/".$row->image;
                            }

                            if($integrate_gallery)//if gallery plgin is used
                            {
                                $query = "SELECT * FROM `#__sobi2_plugin_gallery` WHERE itemid=".$row->itemid." LIMIT 1";
                                $db->setQuery( $query );
                                $image=$db->loadObject();
                                $img='';
                                if($image)
                                {
                                    $thumbSrc = "{$image->itemid}/{$image->thumb}";
                                    $url=$replace ."/images/com_sobi2/gallery/".$thumbSrc;
                                }
                            }
                        }
                        $lists[$i]->image_url = htmlspecialchars($url);
                        $i++;
                    }
                }
            }

        }
        return $lists;
    }//getList() ends

    
}//class plgEmailalertsjma_sobi2category  ends
