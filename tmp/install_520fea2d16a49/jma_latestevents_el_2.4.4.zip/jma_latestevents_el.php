<?php
/*
 * @package Latest Events - Eventlist  Plugin for J!MailALerts Component
 * @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
 * @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
 * @link     http://www.techjoomla.com
 */
// Do not allow direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.plugin.plugin' );

/*load language file for plugin frontend*/
$lang = & JFactory::getLanguage();
$lang->load('plg_emailalerts_jma_latestevents_el', JPATH_ADMINISTRATOR);

//include plugin helper file
$jma_helper=JPATH_SITE.DS.'components'.DS.'com_jmailalerts'.DS.'helpers'.DS.'plugins.php';
if(JFile::exists($jma_helper)){
	include_once($jma_helper);
}
else//this is needed when JMA integration plugin is used on sites where JMA is not installed
{
	if(JVERSION>'1.6.0'){
		$jma_integration_helper=JPATH_SITE.DS.'plugins'.DS.'system'.DS.'plg_sys_jma_integration'.DS.'plg_sys_jma_integration'.DS.'plugins.php';
	}else{
		$jma_integration_helper=JPATH_SITE.DS.'plugins'.DS.'system'.DS.'plg_sys_jma_integration'.DS.'plugins.php';
	}
	if(JFile::exists($jma_integration_helper)){
		include_once($jma_integration_helper);
	}
}
//class plgEmailalertsjma_latestevents_el extends JPlugin
class plgEmailalertsjma_latestevents_el extends JPlugin
{
    function plgEmailalertsLatestevents(& $subject, $config)
    {
        parent::__construct($subject, $config);
        if($this->params===false) {//unknown
            $jPlugin =& JPluginHelper::getPlugin('emailalerts','jma_latestevents_el');
            $this->params = new JParameter( $jPlugin->params);
        }
    }

    function onEmail_jma_latestevents_el($id, $date, $userparam, $fetch_only_latest)
    {
        $areturn	=  array();
        if(!$id)
		{
        	$areturn[0] =$this->_name;
		    $areturn[1]	= '';
            $areturn[2]	= '';
            return $areturn;
        }          
        $list = $this->getList($userparam,$id,$fetch_only_latest,$date);
       
        $areturn[0]	= $this->_name;
        if(empty($list))//if there are no new events, construct an  array with (1=>'', 2=>'') and return it.
        {	
			//if no output is found, return array with 2 indexes with NO values
            $areturn[1]	= '';
            $areturn[2]	= '';
        }
        else
        {	
			//get all plugin parameters in the variable, this will be passed to plugin helper function
			$plugin_params =& $this->params;
            //create object for helper class
			$helper = new pluginHelper();    
            $ht = $helper->getLayout($this->_name, $list,$plugin_params);
            
            $areturn[1]	= $ht;
            //$cssfile= $this->_getCSSLayoutPath($this->_name);
            $cssfile= $helper->getCSSLayoutPath($this->_name,$plugin_params);
            
            $cssdata=JFile::read($cssfile);
            $areturn[2] = $cssdata;
        }
        
        return $areturn;
    }//onBeforeAlertEmail() ends

   

    function getList(&$userparam, &$id, $fetch_only_latest, $date)
    {	
        $mainframe = JFactory::getApplication();

        $db			=& JFactory::getDBO();
        $user		=& JFactory::getUser($id);
        $user_gid	= (int) $user->get('aid');

        $params = $this->params;

        //get user preferences for this plugin parameters(shown in frontend) 
        $userId		= (int) $user->get('id');
        $count		= (int) $userparam['count'];
        $catid		= trim( $userparam['catid'] );
        $venid		= trim($userparam['venid']);
        $el_version	= $userparam['el_version'];	
        
		//version filter
        if($el_version=='old')
        {
			
            $where = ' WHERE a.published = 1 AND a.dates >= CURDATE()';
            $order = ' ORDER BY a.dates ASC, a.times ASC';
            $query = 'SELECT a.*,c.access,c.catname,l.venue, l.city, l.url,'
            .' CASE WHEN CHAR_LENGTH(a.alias) THEN CONCAT_WS(\':\', a.id, a.alias) ELSE a.id END as slug'
            .' FROM #__eventlist_events AS a'
            .' LEFT JOIN #__eventlist_venues AS l ON l.id = a.locid'
            .' LEFT JOIN #__eventlist_categories AS c ON c.id = a.catsid'
            . $where
            .' AND c.access <= '.$user_gid
            .' AND c.id IN ('.$catid.')';

  		    if($venid){
	        	$query .=' AND l.id IN ('.$venid.')';
            }
            //get only fresh content
            if($fetch_only_latest)
            {
                $query .=" AND a.created >=";
                $query .=$db->Quote($date);
            }
           
        }
        else
        {   
            $where = ' WHERE ee.published = 1 AND ee.dates >= CURDATE()';
            $order = ' ORDER BY ee.dates ASC, ee.times ASC';
            $query = 'SELECT ee.*,c.access,c.catname,l.venue, l.city, l.url'
            .' FROM #__eventlist_events AS ee'
            .' LEFT JOIN #__eventlist_venues AS l ON l.id = ee.locid'
            .' LEFT JOIN #__eventlist_cats_event_relations AS eser ON eser.itemid=ee.id'
            .' LEFT JOIN #__eventlist_categories AS c ON c.id=eser.catid'
            . $where
            .' AND c.access <= '.$user_gid
            .' AND c.id IN ('.$catid.')';
			
			if($venid){
				
            	$query .=' AND l.id IN ('.$venid.')';
            }
            //get only fresh content
            if($fetch_only_latest)
            {
                $query .=" AND ee.created >=";
                $query .=$db->Quote($date);
            }
        }
        $query .= $order .' LIMIT '.(int) $userparam['count'];
 
        $db->setQuery($query);
        $rows = $db->loadObjectList();
 
        if(empty($rows)) {return null;}
        $i		= 0;
        $lists	= array();
        $replace = JURI::root();
        
        $mainframe = JFactory::getApplication();
        if($mainframe->isAdmin())//if email is previewed from backend, do not generate sef urls as it won't work
        {
            foreach ( $rows as $row )
            {
                $lists[$i]->link = JRoute::_($replace.'index.php?option=com_eventlist&amp;view=details&amp;id='.$row->id );
                $lists[$i]->dates = $row->dates;
                $lists[$i]->enddates = $row->enddates;
                $lists[$i]->venue = $row->venue;
                $lists[$i]->text = htmlspecialchars( $row->title );
                $lists[$i]->category = htmlspecialchars( $row->catname );
                $i++;
            }
        }
        else//if email is previewed/generated from frontend, generate sef urls
        {
            foreach ( $rows as $row )
            {
                $lists[$i]->link = JURI::root().substr(JRoute::_('index.php?option=com_eventlist&view=details&id='.$row->id),strlen(JURI::base(true))+1);
                $lists[$i]->dates = $row->dates;
                $lists[$i]->enddates = $row->enddates;
                $lists[$i]->venue = $row->venue;
                $lists[$i]->text = htmlspecialchars( $row->title );
                $lists[$i]->category = htmlspecialchars( $row->catname );
                $i++;
            }
        }
        
        return $lists;
    }//getList() ends
}//class plgEmailalertsjma_latestevents_el ends
