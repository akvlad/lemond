<?php
/*
	* @package Latest Events - Eventlist  Plugin for J!MailALerts Component  
	* @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
	* @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
	* @link     http://www.techjoomla.com
*/
defined('_JEXEC') or die('Restricted access');
$params =& $this->params;	?>
	<h2 class="subTitle"><?php //echo $params->get('plugintitle');
								echo $plugin_params->get("plugintitle"); ?></h2>
	<table  class="product-table jma_eventel" >
		<tr>
			<th class = "jma_eventel_th"><?php echo JText::_("EVENT_NAME_LE_EL"); ?></th>
			<th  class = "jma_eventel_th"><?php echo JText::_("VENUE_LE_EL"); ?></th>
			<th  class = "jma_eventel_th"><?php echo JText::_("START_DATE_LE_EL"); ?></th>
			<th  class = "jma_eventel_th"><?php echo JText::_("END_DATE_LE_EL"); ?></th>
			<th  class = "jma_eventel_th"><?php echo JText::_("CATEGORY_LE_EL"); ?></th>
		</tr>
		<?php
		foreach ($vars as $row)
		{
		?>
		<tr>
			<td class="jma_eventel_td"><a href="<?php echo $row->link;?>"><?php echo $row->text; ?></a></td>					
			<td class="jma_eventel_td"><?php echo $row->venue; ?> </td>
			<td class="jma_eventel_td"><?php echo $row->dates; ?> </td>
			<td class="jma_eventel_td"><?php echo $row->enddates; ?> </td>
			<td class="jma_eventel_td"><?php echo $row->category; ?> </td>
		</tr>				    
		<?php 	
		}?>
	</table>
