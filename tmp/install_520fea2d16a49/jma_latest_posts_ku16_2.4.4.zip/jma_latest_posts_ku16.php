<?php
/*
 * @package Latest Posts-Kunena  Plugin for J!MailALerts Component
 * @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
 * @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
 * @link     http://www.techjoomla.com
 */
// Do not allow direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.plugin.plugin' );
/*load language file for plugin frontend*/
$lang = & JFactory::getLanguage();
$lang->load('plg_emailalerts_jma_latest_posts_ku16', JPATH_ADMINISTRATOR);
//include plugin helper file
$jma_helper=JPATH_SITE.DS.'components'.DS.'com_jmailalerts'.DS.'helpers'.DS.'plugins.php';
if(JFile::exists($jma_helper)){
	include_once($jma_helper);
}
else//this is needed when JMA integration plugin is used on sites where JMA is not installed
{
	if(JVERSION>'1.6.0'){
		$jma_integration_helper=JPATH_SITE.DS.'plugins'.DS.'system'.DS.'plg_sys_jma_integration'.DS.'plg_sys_jma_integration'.DS.'plugins.php';
	}else{
		$jma_integration_helper=JPATH_SITE.DS.'plugins'.DS.'system'.DS.'plg_sys_jma_integration'.DS.'plugins.php';
	}
	if(JFile::exists($jma_integration_helper)){
		include_once($jma_integration_helper);
	}
}
//class plgEmailalertsjma_latest_posts_ku16 extends JPlugin
class plgEmailalertsjma_latest_posts_ku16 extends JPlugin
{
    function plgEmailalertsKuposts(& $subject, $config)
    {
        parent::__construct($subject, $config);
    }

    function onEmail_jma_latest_posts_ku16($id, $date, $userparam, $fetch_only_latest)
    {
        $areturn	=  array();
        if(!$id)
		{
        	$areturn[0] =$this->_name;
		    $areturn[1]	= '';
            $areturn[2]	= '';
            return $areturn;
        } 
        
        // create object for helper class
        $helper = new pluginHelper();   
        
        $Itemid	= '';
        $db	= &JFactory::getDBO();
        //Get Parameters
        $params =& $this->params;
        $plugin_params =& $this->params;
        
        $no_of_posts = $userparam['no_of_posts'];
        $catid = $userparam['category']; //1,2,3
        if ($catid)
        {
            $ids = explode( ',', $catid );
            JArrayHelper::toInteger( $ids );
        }
        $i=0;
        $flag=0;
        $lists= array();
        for($j=0; $j <count($ids); $j++)
        {
            if($flag){
                break;
            }
            $uid=$id;
            if ($uid != 0)
            {
                $db->setQuery("SELECT * FROM #__kunena_sessions WHERE userid = {$uid}");
                $session = $db->loadObjectList();
                if ($session) {
                    $lasttime = $session[0]->lasttime;
                    $readtopics = $session[0]->readtopics;
                } else {
                    $lasttime = time() - 1314000; // 1 year
                    $readtopics = '';
                }
            }
            else
            {
                $lasttime = 0;
                $readtopics = '';
            }

            // new indicator
            if ($readtopics) // user have session
            $sql_new = ", (m.time > $lasttime AND m.thread NOT IN ($readtopics)) AS unread";
            elseif ($lasttime) // user don't have session
            $sql_new = ", (m.time > $lasttime) AS unread";
            else // no user
            $sql_new = ", 0 AS unread";
             
            if(JVERSION >= '1.6.0'){
            	$sql_access='';
            }else{
            	$sql_access = 'AND c.pub_access in (0,1,-1,18)';
            }
             
            $qry = "
			SELECT q.maxid AS id, m.time, m.thread, n.hits, q.countid AS `count`, m.subject, m.userid, m.name, m.catid, q.catname, t.message $sql_new 
			FROM
				(SELECT max(m.id) AS maxid, count(m.id) AS countid, c.name AS catname
				FROM #__kunena_messages AS m 
				JOIN #__kunena_categories as c ON m.catid = c.id
				WHERE c.published = 1 AND m.hold = 0 AND m.moved = 0 $sql_access
				GROUP BY m.thread ORDER BY maxid DESC LIMIT $no_of_posts) 
			AS q
			JOIN #__kunena_messages AS m ON q.maxid = m.id
			JOIN #__kunena_messages AS n ON m.thread = n.id
			JOIN #__kunena_messages_text AS t ON q.maxid = t.mesid";
            $qry .=" WHERE m.catid  = ".$ids[$j];
            if($fetch_only_latest)
            {
                $qry .=" AND FROM_UNIXTIME(m.time) >";
                $qry .=$db->Quote($date);
            }
            $db->setQuery($qry);
            $newposts = $db->loadObjectList();
            $replace = JURI::root();
            $link = 'com_kunena';
            $Itemid = $helper->getItemId($link);
            if($newposts)
            {
                $mainframe = JFactory::getApplication();
                if($mainframe->isAdmin())
                {
                    foreach ($newposts as $newpost)
                    {
                        $newp=$replace."index.php?option=com_kunena&func=view&catid=".$newpost->catid."&id=".$newpost->thread."&Itemid=".$Itemid;
                        $newp =JRoute::_( $newp.'#'.$newpost->id);
                        $lists[$i]->link= str_replace("&","&amp;",$newp);
                        $lists[$i]->subject= htmlspecialchars($newpost->subject);
                        $lists[$i]->time= $newpost->time;
                        $lists[$i]->catid= $newpost->catid;
                        $lists[$i]->catname= htmlspecialchars ($newpost->catname);
                        $i++;
                    }
                }
                else
                {
                    require_once(JPATH_SITE.DS.'components'.DS.'com_kunena'.DS.'router.php');
                    foreach ($newposts as $newpost)
                    {
                        /*$newp=$replace."index.php?option=com_kunena&func=view&catid=".$newpost->catid."&id=".$newpost->thread."&Itemid=".$Itemid;
                         $newp =JRoute::_( $newp.'#'.$newpost->id);
                         $lists[$i]->link= str_replace("&","&amp;",$newp);*/
                        //$newp="index.php?option=com_kunena&func=view&catid=".$newpost->catid."&id=".$newpost->thread."&Itemid=".$Itemid;
                        $newp=KunenaRoute::_('index.php?option=com_kunena&func=view&catid='.$newpost->catid.'&id='.$newpost->thread);
                        $newp=$newp.'#'.$newpost->id;
                        $lists[$i]->link=JURI::root().substr(JRoute::_($newp),strlen(JURI::base(true))+1);
                        $lists[$i]->subject= htmlspecialchars($newpost->subject);
                        $lists[$i]->time= $newpost->time;
                        $lists[$i]->catid= $newpost->catid;
                        $lists[$i]->catname= htmlspecialchars ($newpost->catname);
                        $i++;
                    }
                }
            }
            if ( $i >= $no_of_posts)
            {
                $flag=1;
                break;
            }
        }
        $areturn[0]	= $this->_name;

        if($i==0)
        {//if there are no new groups, construct an  array with (0=>'Kuposts', 1=>'') and return it.
            $areturn[1]	= '';
            $areturn[2]	= '';
        }//if ends
        else
        {
			//$ht = $this->_getLayout($this->_name, $lists);
            $ht = $helper->getLayout($this->_name, $lists,$plugin_params);
            
            $areturn[1]	= $ht;
            //$cssfile= $this->_getCSSLayoutPath($this->_name);
            $cssfile= $helper->getCSSLayoutPath($this->_name,$plugin_params);
            $cssdata=JFile::read($cssfile);
            $areturn[2] = $cssdata;
        }
        return $areturn;
    }

    

   
}//plgEmailalertsjma_latest_posts_ku16 class ends
