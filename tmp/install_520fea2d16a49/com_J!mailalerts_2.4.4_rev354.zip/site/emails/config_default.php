<?php 

$emails_config=array(
'private_key_cronjob'=>"qwertya1b2c3qwerty",
'enb_debug'=>"1",
'enb_batch'=>"1",
'inviter_percent'=>"45",
'intro_msg'=>"Hey! you can set the preferences as you want to receive the mail alert!",
'jstoolbar'=>"0"
);

?>
