<?php
defined('_JEXEC') or die('Restricted access');
$disp_name=$vars[0];
$rows=$vars[1];
$replace = JURI::root();
$img_path = $replace . "/images/comprofiler";
$mainframe = JFactory::getApplication();
?>
<h2 class="subTitle">
<?php 
echo $plugin_params->get("plugintitle");
?>
</h2>
<table class="jma_latestuser product-table">
<?php

$i = 1;$k=1;
foreach ($rows as $row)
{
    if($i==1) {
    echo "<tr>";
    }
     
    if($disp_name == 1)
    {
       	$Itemid=$this->getItemId('index.php?option=com_community');
        if($mainframe->isAdmin())
        {
            $link=JRoute::_($replace.'index.php?option=com_community&amp;view=profile&amp;userid='.$row->id.'&amp;Itemid='.$Itemid);
        }
        else
        {
            $link=JURI::root().substr(CRoute::_('index.php?option=com_community&view=profile&userid='.$row->id),strlen(JURI::base(true))+1);
        }
    }
    if($disp_name == 2)
    {
        $Itemid=$this->getItemId('index.php?option=com_comprofiler');
        if($mainframe->isAdmin())
        {
          $link=JRoute::_($replace.'index.php?option=com_comprofiler&amp;task=viewprofile&amp;user='.$row->id.'&amp;Itemid='.$Itemid);
        }
        else
        {
            //$link =JRoute::_('index.php?option=com_comprofiler&amp;task=viewprofile&amp;user=' . $row->id . '&amp;Itemid=' . $Itemid);
            $link=JURI::root().substr(JRoute::_('index.php?option=com_comprofiler&task=viewprofile&user='.$row->id.'&Itemid='.$Itemid),strlen(JURI::base(true))+1);
        }
    }
    if($disp_name == 1)//jomsocial
    {
        //to get jomsocial avatar
        $user1 =& CFactory::getUser($row->id);
        $uimage = $user1->getThumbAvatar();
        $user=JFactory::getUser();
        if ( !$mainframe->isSite() )
        {
            $uimage = str_replace('administrator/','',$uimage);
        }
    }
     
    if($disp_name == 2)//cb
    {
        if($row->avatar)
        {
            if (substr_count($row->avatar, "/") == 0)
            {
                $uimage = $img_path . '/tn' . $row->avatar;
            }
            else
            {
                $uimage = $img_path . '/' . $row->avatar;
            }
        }
        elseif ($row->avatar)
        {
            $uimage = $replace."components/com_comprofiler/plugin/language/default_language/images/tnpendphoto.jpg";
        }
        else
        {
            $uimage = $replace."components/com_comprofiler/plugin/language/default_language/images/tnnophoto.jpg";
        }

    }
    $show_name =$plugin_params->get('show_name','username');
    if($show_name=='name'){
        $name=$row->name;
    }else{
        $name=$row->username;
    }
    if($disp_name == 0)//joomla
    {
        echo '<td class="jma_user_nm jma_latestuser_td"><span class="jma_prefspan">'.$name.'</span><br /></td>	';
    }
    else
    {
        echo '<td class="jma_user_img">
					<div>
						<a href="'.$link.'" target="_blank">
							<img class="jma_latestuser_img" src="'.$uimage.'" alt="'.$name.'"/>
						</a>
					</div>
					</td>
					<td class="jma_user_nm jma_latestuser_td">
						<a href="'.$link.'" target="_blank">
							<span class="jma_prefspan">'.$name.'</span>
						</a><br />
					</td>';
    }
     
    $i++;$k++;
    if($i > 3){
        $i = 1;
        ?>
	</tr>
	<?php
    }
}//foreach ends
?>
</table>
