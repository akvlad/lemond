<?php
/*
 * @package Latest Users Plugin for J!MailAlerts Component
 * @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
 * @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
 * @link     http://www.techjoomla.com
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.plugin.plugin' );

/*load language file for plugin frontend*/
$lang = & JFactory::getLanguage();
$lang->load('plg_emailalerts_jma_latestusers', JPATH_ADMINISTRATOR);

//include plugin helper file
$jma_helper=JPATH_SITE.DS.'components'.DS.'com_jmailalerts'.DS.'helpers'.DS.'plugins.php';
if(JFile::exists($jma_helper)){
	include_once($jma_helper);
}
else//this is needed when JMA integration plugin is used on sites where JMA is not installed
{
	if(JVERSION>'1.6.0'){
		$jma_integration_helper=JPATH_SITE.DS.'plugins'.DS.'system'.DS.'plg_sys_jma_integration'.DS.'plg_sys_jma_integration'.DS.'plugins.php';
	}else{
		$jma_integration_helper=JPATH_SITE.DS.'plugins'.DS.'system'.DS.'plg_sys_jma_integration'.DS.'plugins.php';
	}
	if(JFile::exists($jma_integration_helper)){
		include_once($jma_integration_helper);
	}
}

/*included to get jomsocial avatar*/
$jspath=JPATH_ROOT.DS.'components'.DS.'com_community';
if(JFolder::exists($jspath)){
	include_once($jspath.DS.'libraries'.DS.'core.php');
}

//class plgPluginTypePluginName extends JPlugin
class plgEmailalertsjma_latestusers extends JPlugin
{
    function plgEmailalertsLatestusers(& $subject, $config)
    {
        parent::__construct($subject, $config);
        if($this->params===false)
		{
            $jPlugin =& JPluginHelper::getPlugin('emailalerts','jma_latestusers');
            $this->params = new JParameter( $jPlugin->params);
        }
    }

    function onEmail_jma_latestusers($id, $date, $userparam, $fetch_only_latest)
    {
        $areturn	=  array();
        if(!$id)
		{
        	$areturn[0] =$this->_name;
		    $areturn[1]	= '';
            $areturn[2]	= '';
            return $areturn;
        }        
        //Required Declarations
        $db		=& JFactory::getDBO();
        $plugnam = & $this->_name;
        
        //get all plugin parameters in the variable, this will be passed to plugin helper function
		$plugin_params =& $this->params;
			
        $no_of_users='';
        //get user preferences for this plugin parameters(shown in frontend) 
        $no_of_users=$userparam['no_of_users'];
        
        //get plugin parameters(not shown in frontend) 
        $disp_name =&$this->params->get('disp_name',0);
        $show_name =&$this->params->get('show_name','username');
        $show_users_with_avatar=&$this->params->get('show_users_with_avatar',0);

        switch($disp_name)
        {

            case 0 :
                //joomla
                $query = " SELECT ". $show_name ."
					 FROM ".$db->nameQuote('#__users');
                $query .=" WHERE block=0 ";
                if($id){
			 		$query .=" AND id<>".$id;
			 	}
		 		//get only fresh content
                if($fetch_only_latest)
                {
                    $query .=" AND registerDate >= ".$db->Quote($date);
                }
                $query .=" ORDER BY ".$db->nameQuote('registerDate')." DESC ";
                break;
            case 1:
                //jomsocial
                $query = " SELECT a.".$show_name ." , a.id, b.thumb
				FROM ".$db->nameQuote('#__users')." AS a, ".$db->nameQuote('#__community_users')." AS b"; 
                $query .=" WHERE a.id = b.userid
						   AND a.block = 0 ";
				
				if($id){
			 		$query .=" AND b.userid<>".$id ;
			 	}
		 		
                if($show_users_with_avatar){
                    $query .=" AND b.avatar<>''";
                }
				//get only fresh content	
                if($fetch_only_latest)
                {
                    $query .=" AND a.registerDate >= ";
                    $query .=$db->Quote($date);
                }
                $query.=" ORDER BY `a`.".$db->nameQuote('registerDate')." DESC";
                break;
            case 2:
                //community builder
                $query = " SELECT a.".$show_name." , a.id, b.avatar
				FROM ".$db->nameQuote('#__users')." AS a, ".$db->nameQuote('#__comprofiler')." AS b";
                $query .=" WHERE a.id = b.user_id
						   AND b.approved=1
						   AND b.confirmed=1 ";
				
				if($id){
			 		$query .=" AND b.user_id <>".$id;
			 	}		   
						   
                if($show_users_with_avatar){
                    $query .=" AND b.avatar<>''";
                }
				//get only fresh content
                if($fetch_only_latest)
                {
                    $query .=" AND a.registerDate >= ";
                    $query .=$db->Quote($date);
                }
                $query.=" ORDER BY `a`.".$db->nameQuote('registerDate')." DESC";
                break;
        }
        //use user's preferred value for count
        $query .=" LIMIT 0 , $no_of_users";

        $db->setQuery($query);
        $userinfo = $db->loadObjectList(); 
        
        $areturn	=  array();
        $areturn[0]	= $this->_name;
        if($userinfo == null)
        {
            //if no output is found, return array with 2 indexes with NO values
            $areturn[1]	= '';
            $areturn[2]	= '';
        }
        else
        { 
            //create object for helper class
       		$helper = new pluginHelper(); 
            //set other values needed in plugin template file and pass to helper function
            $vars[0]=$disp_name;
            $vars[1]=$userinfo;
            //call helper function to get plugin layout
            $ht = $helper->getLayout($this->_name,$vars,$plugin_params);
            $areturn[1]	= $ht;
            //call helper function to get plugin CSS layout path  
            $cssfile=$helper->getCSSLayoutPath($this->_name,$plugin_params);
            $cssdata=JFile::read($cssfile);
            $areturn[2] = $cssdata;
        }
        return $areturn;
    }//onEmail_jma_latestusers() ends

}//class plgEmailalertsjma_latestusers  ends
