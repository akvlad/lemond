<?php
/*
 * @package Latest Photo-Phoca Gallery  Plugin for J!MailALerts Component
 * @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
 * @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
 * @link     http://www.techjoomla.com
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/*load language file for plugin frontend*/
$lang = & JFactory::getLanguage();
$lang->load('plg_emailalerts_jma_latestphoto_pg', JPATH_ADMINISTRATOR);

//include plugin helper file
$jma_helper=JPATH_SITE.DS.'components'.DS.'com_jmailalerts'.DS.'helpers'.DS.'plugins.php';
if(JFile::exists($jma_helper)){
	include_once($jma_helper);
}
else//this is needed when JMA integration plugin is used on sites where JMA is not installed
{
	if(JVERSION>'1.6.0'){
		$jma_integration_helper=JPATH_SITE.DS.'plugins'.DS.'system'.DS.'plg_sys_jma_integration'.DS.'plg_sys_jma_integration'.DS.'plugins.php';
	}else{
		$jma_integration_helper=JPATH_SITE.DS.'plugins'.DS.'system'.DS.'plg_sys_jma_integration'.DS.'plugins.php';
	}
	if(JFile::exists($jma_integration_helper)){
		include_once($jma_integration_helper);
	}
}

require_once( JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_phocagallery' . DS . 'libraries' . DS .'loader.php');
require_once( JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_phocagallery' . DS . 'libraries' . DS . 'phocagallery' .DS . 'file' .DS .'filethumbnail.php');

if (!JComponentHelper::isEnabled('com_phocagallery', true)) {
    return JError::raiseError(JText::_('Phoca Gallery Error'), JText::_('Phoca Gallery is not installed on your system'));
}
if (! class_exists('PhocaGalleryLoader')) {
    require_once( JPATH_ADMINISTRATOR.DS.'components'.DS.'com_phocagallery'.DS.'libraries'.DS.'loader.php');
}
phocagalleryimport('phocagallery.path.path');
phocagalleryimport('phocagallery.path.route');
phocagalleryimport('phocagallery.library.library');
phocagalleryimport('phocagallery.text.text');
phocagalleryimport('phocagallery.access.access');
phocagalleryimport('phocagallery.file.file');
phocagalleryimport('phocagallery.file.filethumbnail');
phocagalleryimport('phocagallery.image.image');
phocagalleryimport('phocagallery.image.imagefront');
phocagalleryimport('phocagallery.render.renderfront');
phocagalleryimport('phocagallery.ordering.ordering');
phocagalleryimport('phocagallery.picasa.picasa');


class plgEmailalertsjma_latestphoto_pg extends JPlugin
{
    function plgEmailalertsLatestphotopg(& $subject, $config){
        parent::__construct($subject, $config);

        if($this->params===false) {
            $jPlugin =& JPluginHelper::getPlugin('emailalerts','jma_latestphoto_pg');
            $this->params = new JParameter( $jPlugin->params);
        }
    }
     
    function onEmail_jma_latestphoto_pg($id, $date, $userparam, $fetch_only_latest)
    {
              
        $areturn	=  array();
        if(!$id)
		{
        	$areturn[0] =$this->_name;
		    $areturn[1]	= '';
            $areturn[2]	= '';
            return $areturn;
        }        
        $userinfo = $this->getPhotos($id,$userparam,$fetch_only_latest,$date);
       
        $areturn[0]	= $this->_name;
        if($userinfo == null)
        {	
			//if no output is found, return array with 2 indexes with NO values
            $areturn[1]	= '';
            $areturn[2]	= '';
        }
        else
        {
            //get all plugin parameters in the variable, this will be passed to plugin helper function
	        $plugin_params=&$this->params;
            //create object for helper class
	        $helper = new pluginHelper();    
            //call helper function to get plugin layout
            $ht = $helper->getLayout($this->_name, $userinfo,$plugin_params);
            
            $areturn[1]	= $ht;
			//call helper function to get plugin CSS layout path
            $cssfile= $helper->getCSSLayoutPath($this->_name,$plugin_params);
            
            $cssdata=JFile::read($cssfile);
            $areturn[2] = $cssdata;
        }
        return $areturn;
    }
    
    function getPhotos($id,$userparam,$fetch_only_latest,$last_alert_date)
    {
        $db =& JFactory::getDBO();
        $params = $this->params;
        
        //get user preferences for this plugin parameters(shown in frontend) 
        $count		= (int) $userparam['count'];
       
        
        $replace = JURI::root();
        $sql  = "	SELECT a.id, a.filename, a.title, a.catid, cc.alias as catalias,a.alias,a.extm,a.extw,a.exth,a.exts,a.extid, a.description
					FROM #__phocagallery_categories AS cc
					LEFT JOIN #__phocagallery AS a ON a.catid = cc.id
					WHERE a.published = 1";
		
		//get only fresh content
        if($fetch_only_latest)
        {
            $sql .=" AND a.date >= ";
            $sql .= $db->Quote($last_alert_date);
        }
        //use user's preferred value for count
        $sql .= " ORDER BY
							a.date DESC
					LIMIT 
							0,".$count;
        $query = $db->setQuery($sql);
        $row  = $db->loadObjectList();

        $i = 0;
        $imgCatSize	= 'medium';
        $mainframe = JFactory::getApplication();
        foreach($row as $valueImages)
        {
            // Get file thumbnail or No Image
            if ($valueImages->extm != '') {

                if ($valueImages->extw != '')
                {
                    $extw 				= explode(',',$valueImages->extw);
                    $valueImages->extw	= $extw[1];
                }
                if ($valueImages->exth != '')
                {
                    $exth 				= explode(',',$valueImages->exth);
                    $valueImages->exth	= $exth[1];
                }
                $valueImages->extpic	= 1;
                $valueImages->linkthumbnailpathabs	= $valueImages->extm;
            }
            else
            {
                $valueImages->linkthumbnailpath  	= PhocaGalleryImageFront::displayCategoryImageOrNoImage($valueImages->filename,$imgCatSize);
                $file_thumbnail 					= PhocaGalleryFileThumbnail::getThumbnailName($valueImages->filename, $imgCatSize);
                $valueImages->linkthumbnailpathabs	= $file_thumbnail->abs;
            }

            // Different links for different actions: image, zoom icon, download icon
            $thumbLink	= PhocaGalleryFileThumbnail::getThumbnailName($valueImages->filename, 'large');
            $thumbLinkM	= PhocaGalleryFileThumbnail::getThumbnailName($valueImages->filename, 'medium');

            // ROUTE
            $suffix	= '&detail=0&buttons=1';
            if($mainframe->isAdmin())
            {
                $siteLink=JRoute::_($replace.PhocaGalleryRoute::getImageRoute($valueImages->id, $valueImages->catid, $valueImages->alias, $valueImages->catalias, 'detail', $suffix ));
                $siteLink=str_replace("&", "&amp;",$siteLink);
                $valueImages->link=$siteLink;
            }
            else
            {
                $siteLink=PhocaGalleryRoute::getImageRoute($valueImages->id,$valueImages->catid,$valueImages->alias,$valueImages->catalias,'detail',$suffix);
                $valueImages->link=JURI::root().substr(JRoute::_($siteLink),strlen(JURI::base(true))+1);
            }
        }
        if($db->getErrorNum()) {
            JError::raiseError( 500, $db->stderr());
        }
        return $row;
    }//getPhotos() ends

    
}//plgEmailalertsjma_latestphoto_pg class ends
