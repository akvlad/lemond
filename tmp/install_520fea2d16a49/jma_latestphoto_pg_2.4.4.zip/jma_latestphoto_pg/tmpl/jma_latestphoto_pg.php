<?php
/*
	* @package Latest Photo-Phoca Gallery  Plugin for J!MailALerts Component  
	* @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
	* @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
	* @link     http://www.techjoomla.com
*/

defined('_JEXEC') or die('Restricted access');
$params =& $this->params;		
$replace = JURI::root();
?>		
	<h2 class="subTitle"> <?php 
	//echo $params->get("plugintitle"); 
	echo $plugin_params->get("plugintitle");
	?></h2>
    <table class = "jma_photo_pg product-table">
<?php			    
		
$i = 1;$k=1;	

foreach ($vars as $data)
{
	if($i==1)
	{ echo "<tr>";}
	$link	= $replace.'index.php?option=com_phocagallery&amp;view=phocagalleryd&amp;tmpl=component&amp;cid[]='.$data->id;
	$refreshUrlThumb = 'index.php?option=com_phocagallery&amp;view=phocagallerys';
	$thumb = PhocaGalleryFileThumbnail::getOrCreateThumbnail($data->filename,$refreshUrlThumb,1,1,1 );
?>
	<td class="jma_photo_pg_td">
				
		<?php 
		if (isset($data->extid) && $data->extid != '') 
		{
		?>
				<a href="<?php echo $data->link; ?>">
					<img class="jma_photo_pg_img" alt="<?php echo $data->title; ?>" src="<?php echo $data->exts; ?>"  />
				</a>
		<?}
		else{?>
				<a href="<?php echo $data->link; ?>">
					<img class="jma_photo_pg_img" alt="<?php echo $data->title; ?>" src="<?php echo $replace.$data->linkthumbnailpath; ?>"   />
				</a>
		<?}?>
		
		<a href="<?php echo $data->link; ?>">
			<div>
			<?php echo $data->title; ?>
			</div>
		</a>
		
	</td>
	<?	 
	$i++;$k++;
 	if($i > 3){
		$i = 1;	
		?>
		</tr>
		<?php
	}
}//foreach ends
?>
</table>
