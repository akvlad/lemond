<?php
/**
 * @package Latest Items - k2 for J!MailAlerts Plugin
 * @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
 * @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
 * @link     http://www.techjoomla.com <http://www.techjoomla.com/>
 */
defined('_JEXEC') or die('Restricted access');
$params =& $this->params;	?>
<h2 class="subTitle">
	<?php echo $plugin_params->get('plugintitle');
	?>
</h2>
<?php 
foreach($vars as $key=>$displc){
	$arr[$displc->name][]=$displc;
}

$show_cat_image= $plugin_params->get('show_cat_image');
?>
<table class="jma_k2 product-table">
<?php
foreach($arr as $ar)
{
	$i=0;
	foreach($ar as $a)
	{
		if(!$i)
		{
			$i++;
			?>
			<?php
			if(!empty($a->image) && $show_cat_image)
			{
				?>
				<tr class="jma_k2_tr" >
					<td>
						<img class="jma_k2_img"	src="<?php echo JURI::root();?>media/k2/categories/<?php echo $a->image; ?>" />
					</td>
					<td class="jma_k2_td_cat_name">	
						<?php echo $a->name; ?>
					</td>
				</tr>
				<?php
			}
			else
			{
				?>
				<tr class="jma_k2_tr">
					<td colspan="2" class="jma_k2_td_cat_name">
						<?php echo $a->name; ?>
					</td>
				</tr>
				<?php
			}
				?>
				<tr>
					<td  class="jma_k2_td">
						<li class="jma_k2_li">
							<a href="<?php echo $a->link;?>"><?php echo $a->title;?></a>
						</li>
					</td>
				</tr>
				<?php
		}
		else
		{
				?>
			<tr>
				<td class="jma_k2_td">
					<li class="jma_k2_li">
						<a href="<?php echo $a->link;?>"><?php echo $a->title;?></a>
					</li>
				<td>
			</tr>
			<?php
		}
	}
}
?></table>
