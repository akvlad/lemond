<?php
/**
 * @copyright    Copyright (C) 2009 Open Source Matters. All rights reserved.
 * @license      GNU/GPL
 */

// Check to ensure this file is within the rest of the framework
defined('JPATH_BASE') or die();

/**
 * Renders a multiple item select element using SQL result and explicitly specified params

 * HOW TO USE IN XML ?? example is given below
 => <param name="catid" type="jmacategoriesk2" default="1" label="LBL_CATEGORY_K2" element="jma_latest_content_k2" multiple="multiple" description="DESC_CATEGORY_K2" key_field='id' value_field='name' />

 * where element is the name of your plugin entry file

 */
jimport('joomla.html.html');
jimport( 'joomla.plugin.helper' );
require_once(JPATH_SITE.DS.'libraries/joomla/form/fields/list.php');
class JFormFieldJmacategoriesk2 extends JFormFieldList
{
    /**
     * Element name
     *
     * @access       protected
     * @var          string
     */
    var    $_name = 'Jmacategoriesk2';

    protected function getOptions()
    {

        	
        //get plugin name (plugin entryfile name)
        	
        $db  = & JFactory::getDBO();
        	
        //get plugin params from #__extensions table
        $query= "select params from #__extensions where element='jma_latest_content_k2' && folder='emailalerts'";
        $db->setQuery($query);
        $plug_params=$db->loadResult();
        if(!$plug_params){
            return false;
        }
        if(preg_match_all('/\[(.*?)\]/',$plug_params,$match))
        {
            foreach($match[1] as $mat)
            {
                $match=str_replace(',','|',$mat);
                $plug_params= str_replace($mat,$match,$plug_params);
            }
        }
        $newlin = explode(",",$plug_params);

        foreach($newlin as $v)
        {
            $entry="";
            if(!empty($v))
            {
                $v=str_replace('{','',$v);
                $v=str_replace(':','=',$v);
                $v=str_replace('"','',$v);
                $v=str_replace('}','',$v);
                $v=str_replace('[','',$v);
                $v=str_replace(']','',$v);
                $v=str_replace('|',',',$v);
                $v=explode("=",$v);
                $default_plugin_params[$v[0]]=$v[1];
            }
        }
        if(isset($default_plugin_params['category']))
        {
            $cats=$default_plugin_params['category'];
            if($cats){
                $sql = "SELECT id,name FROM #__k2_categories WHERE published=1 AND id IN (".$cats.")";
            }
            else{
                $sql = "SELECT id,name FROM #__k2_categories WHERE published=1";
            }
        }
        else{
            $sql = "SELECT id,name FROM #__k2_categories WHERE published=1";
        }

        $db->setQuery($sql);

        $options = $db->loadObjectList();
         
        if($options)
        {
            foreach ($options as $i=>$option) {
                $options[$i]->text = JText::_($option->name);
                $options[$i]->value = JText::_($option->id);
            }
            //Merge any additional options in the XML definition.
            $options = array_merge(parent::getOptions(), $options);
            return $options;
        }
        else{
            return JText::_('NO_CATS_MSG');
        }
    }
}
