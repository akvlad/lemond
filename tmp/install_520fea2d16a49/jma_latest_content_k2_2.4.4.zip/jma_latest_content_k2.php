<?php
/**
 * @package Latest Posts - k2 for J!MailAlerts Plugin
 * @copyright Copyright (C) 2009 -2010 Techjoomla, Tekdi Web Solutions . All rights reserved.
 * @license GNU GPLv2 <http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
 * @link     http://www.techjoomla.com <http://www.techjoomla.com/>
 */
// Do not allow direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.plugin.plugin' );
/*load language file for plugin frontend*/
$lang = & JFactory::getLanguage();
$lang->load('plg_emailalerts_jma_latest_content_k2', JPATH_ADMINISTRATOR);

//include plugin helper file
$jma_helper=JPATH_SITE.DS.'components'.DS.'com_jmailalerts'.DS.'helpers'.DS.'plugins.php';
if(JFile::exists($jma_helper)){
	include_once($jma_helper);
}
else//this is needed when JMA integration plugin is used on sites where JMA is not installed
{
	if(JVERSION>'1.6.0'){
		$jma_integration_helper=JPATH_SITE.DS.'plugins'.DS.'system'.DS.'plg_sys_jma_integration'.DS.'plg_sys_jma_integration'.DS.'plugins.php';
	}else{
		$jma_integration_helper=JPATH_SITE.DS.'plugins'.DS.'system'.DS.'plg_sys_jma_integration'.DS.'plugins.php';
	}
	if(JFile::exists($jma_integration_helper)){
		include_once($jma_integration_helper);
	}
}

//added for k2route
$k2path=JPATH_ROOT.DS.'components'.DS.'com_k2'.DS.'helpers';
include_once($k2path.DS.'route.php');

//class plgEmailalertsjma_latest_content_k2 extends JPlugin
class plgEmailalertsjma_latest_content_k2 extends JPlugin
{
    function plgEmailalertsJma_latest_content_k2(& $subject, $config)
    {
        parent::__construct($subject, $config);
    }

    function onEmail_jma_latest_content_k2( $uid , $date, $userparam , $fetch_only_latest)
    {
		$areturn	=  array();
        if(!$uid)
		{
        	$areturn[0] =$this->_name;
		    $areturn[1]	= '';
            $areturn[2]	= '';
            return $areturn;
        }        
        $Itemid	= '';  
        $db	= &JFactory::getDBO();
		//create object for helper class
	    $helper = new pluginHelper();    
        $params =& $this->params;
		$userId		= (int) $params->get('id');
					
       //get user preferences for this plugin parameters(shown in frontend)   
        $no_of_items= (int) $userparam['no_of_items'];
        $category	= $userparam['category'];
        $catid		= trim( $userparam['catid'] );
        $show_cat_image =$userparam['show_cat_image'];
           
		
		//get data for content		
        $qry="SELECT a.id,a.title,a.created,a.catid,b.name,b.image
		FROM #__k2_items as a, #__k2_categories as b 
		WHERE a.catid=b.id AND a.published = 1 AND a.trash=0 AND a.catid IN (".$catid.") AND a.created_by <> ".$uid; 
		
		//get only fresh content
        if($fetch_only_latest)
        {
            $qry .=" AND created >= ";
            $qry .=$db->Quote($date);
        }
        //use user's preferred value for count
        $qry .=" ORDER BY created DESC LIMIT ".$no_of_items."";
        $db->setQuery($qry);
        $newposts = $db->loadObjectList();
	
        $areturn[0]	= $this->_name;
 
        if($newposts == null)
        {   //if no output is found, return array with 2 indexes with NO values
            $areturn[1]	= '';
            $areturn[2]	= '';
        }
        else
        {    
            $replace = JURI::root();
            $mainframe = JFactory::getApplication();
            if($mainframe->isAdmin())
            {
                foreach ($newposts as $k=>$newpost)
                {
                     $link=$replace."index.php?option=com_k2&amp;view=item&amp;id=".$newpost->id;
                     $itemid=$helper->getItemId('com_k2');
                     $link.='&Itemid='.$itemid;
                     $newposts[$k]->link = JRoute::_($link);
                }
            }
            else
            {
                foreach ($newposts as $k=>$newpost)
                {
                    $link="index.php?option=com_k2&view=item&id=".$newpost->id;
                    $itemid=$helper->getItemId('com_k2');
                    $link.='&Itemid='.$itemid;
                    $newposts[$k]->link=JURI::root().substr(JRoute::_($link),strlen(JURI::base(true))+1);
                }
            }
             //get all plugin parameters in the variable, this will be passed to plugin helper function
	        $plugin_params=&$this->params;
           
            //call helper function to get plugin layout
            $ht = $helper->getLayout($this->_name, $newposts,$plugin_params);
            $areturn[1]	= $ht;
            //call helper function to get plugin CSS layout path
            $cssfile= $helper->getCSSLayoutPath($this->_name,$plugin_params);
            $cssdata=JFile::read($cssfile);
            $areturn[2] = $cssdata;
        } 
        return $areturn;
    }//function onEmail_jma_latest_content_k2 ends

    /*function adItemId($link)
    {
        $query = "SELECT id FROM #__menu WHERE link LIKE '%com_k2%' AND published = 1 ORDER BY id";
        $db	= &JFactory::getDBO();
        $db->setQuery($query);
        $items = $db->loadObjectList();
        if(!isset($items[0])){
            return $link;
        }
        $Itemid = $items[0]->id;
        $link .= "&amp;Itemid=".$Itemid;
        return JRoute::_($link);
    }*/

   
}//onEmail_jma_latest_content_k2 class ends
